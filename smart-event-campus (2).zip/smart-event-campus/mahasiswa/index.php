<?php
$pageTitle = 'Portal Mahasiswa';
require_once __DIR__ . '/../includes/header_mahasiswa.php';
require_once __DIR__ . '/../config/database.php';

$conn = getConnection();
$events = $conn->query("SELECT * FROM events ORDER BY tanggal_event ASC")->fetch_all(MYSQLI_ASSOC);

$totalEvent = count($events);
$totalAkanDatang = count(array_filter($events, fn($e) => $e['status'] === 'Akan Datang'));

$iconKategori = [
    'Seminar' => '🎤',
    'Workshop' => '🛠️',
    'Lomba' => '🏆',
    'Pelatihan' => '📘',
];
?>

<section class="hero" style="padding:44px 24px 60px;">
    <h1 style="font-size:28px;">Halo, <?= clean($_SESSION['mhs_nama']) ?> 👋</h1>
    <p>Berikut daftar kegiatan kampus yang bisa kamu ikuti. NIM: <?= clean($_SESSION['mhs_nim']) ?></p>
</section>

<div class="stats-row" style="max-width:500px;">
    <div class="stat-item">
        <div class="num"><?= $totalEvent ?></div>
        <div class="label">Total Event</div>
    </div>
    <div class="stat-item">
        <div class="num"><?= $totalAkanDatang ?></div>
        <div class="label">Akan Datang</div>
    </div>
</div>

<section class="section">
    <div class="section-head">
        <h2>Daftar Kegiatan Kampus</h2>
        <p>Pilih kategori untuk menyaring kegiatan yang ingin kamu ikuti</p>
    </div>

    <div class="filter-bar">
        <div class="filter-chip active" data-kategori="semua">Semua</div>
        <div class="filter-chip" data-kategori="Seminar">🎤 Seminar</div>
        <div class="filter-chip" data-kategori="Workshop">🛠️ Workshop</div>
        <div class="filter-chip" data-kategori="Lomba">🏆 Lomba</div>
        <div class="filter-chip" data-kategori="Pelatihan">📘 Pelatihan</div>
    </div>

    <?php if (empty($events)): ?>
        <div class="empty-state">
            <div class="icon">🗓️</div>
            <p>Belum ada event yang ditambahkan admin. Silakan cek lagi nanti.</p>
        </div>
    <?php else: ?>
        <div class="event-grid">
            <?php foreach ($events as $event): ?>
                <?php
                    $statusClass = 'status-' . strtolower(str_replace(' ', '-', $event['status']));
                    $tanggal = date('d M Y', strtotime($event['tanggal_event']));
                ?>
                <div class="event-card" data-kategori="<?= clean($event['kategori']) ?>">
                    <div class="event-thumb">
                        <?php if (!empty($event['gambar']) && file_exists(__DIR__ . '/../assets/uploads/' . $event['gambar'])): ?>
                            <img src="<?= base_url('assets/uploads/' . $event['gambar']) ?>" alt="<?= clean($event['judul']) ?>">
                        <?php else: ?>
                            <?= $iconKategori[$event['kategori']] ?? '📅' ?>
                        <?php endif; ?>
                        <span class="event-cat-tag"><?= clean($event['kategori']) ?></span>
                    </div>
                    <div class="event-body">
                        <div class="event-date">📅 <?= $tanggal ?> &middot; ⏰ <?= date('H:i', strtotime($event['waktu_event'])) ?> WIB</div>
                        <h3><?= clean($event['judul']) ?></h3>
                        <p><?= clean($event['deskripsi']) ?></p>
                        <?php if (!empty($event['penyelenggara'])): ?>
                            <p style="font-size:12.5px; color:var(--gray); margin-top:-8px; margin-bottom:14px;">Penyelenggara: <?= clean($event['penyelenggara']) ?></p>
                        <?php endif; ?>
                        <div class="event-meta">
                            <span>📍 <?= clean($event['lokasi']) ?></span>
                            <span class="status-badge <?= $statusClass ?>"><?= clean($event['status']) ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php $conn->close(); ?>

<script src="<?= base_url('assets/js/script.js') ?>"></script>
</body>
</html>
